function setup() {
	createCanvas(windowWidth, windowHeight);
	background(80);

}

function draw()
{
	noStroke();
	if(mouseIsPressed)
	{
		if(mouseButton == LEFT)
		{
			fill(random(255),255,random(255));
		}
		if(mouseButton == RIGHT)
		{
			fill(255,random(255),random(255));
		}
		if(mouseButton == CENTER)
		{
			fill(random(255),random(255),255);
		}
		var size=random(50);
		ellipse(mouseX, mouseY, size, size);
		for(var t=0;t<=10;t++)
		{
			var splashx=random(-7,7);
			var splashy=random(-7,7);
			var signe=-1^(random(7));
			ellipse(mouseX+(splashx*signe),mouseY+(splashy*signe),(size-splashx)/2,(size-splashx)/2);
		}
	}
}

function keyTyped()
{
	if(key=='r' || key=='R') setup(); //Refresh
	if(key=='1') background(80); //default background
	if(key=='2') background(255); //White background
	if(key=='3') background(0); //Black background
	if(key=='4') background(random(255));
	if(key=='5') background(random(255),random(255),random(255));
}
