function Particle(x, y, c) {
	this._xPos = x; this._yPos = y;
	this._xVel = 0; this._yVel = 0;
	this._mass = random(0.003, 0.03);
	this.colour = c;
	
	// moves the particle
	this.move = function() {
		this._xPos += this._xVel;
		this._yPos += this._yVel;
	}
	
	// displays the particle
	this.display = function() {
		fill(this.colour)
		ellipse(this._xPos, this._yPos, this._mass*1000, this._mass*1000)
	};
}