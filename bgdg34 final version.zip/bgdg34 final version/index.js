
class bubble{

constructor(colour,size,object){
this.x = mouseX
this.y = mouseY
this.size = size||random(50)
this.colour = colour ||"red"
this.object = object ||"circle"
if (this.colour == "red"){
	this.r = 255
	this.ga = random(255)
	this.b = random(255)
	this.rgb = [this.r,this.ga,this.b]

}
if(this.colour == "blue"){
	this.r = random(255)
	this.ga = random(255)
	this.b = 255
	this.rgb = [this.r,this.ga,this.b]
}
if(this.colour == "green"){
	this.r = random(255)
	this.ga = 255
	this.b = random(255)
	this.rgb = [this.r,this.ga,this.b]
}
}
setColour(colour){
	this.colour = colour

}
setSize(size){
	this.size = size
}
setObject(object){
	 this.object = object
}
draw(g){

  if(mouseIsPressed && this.object == "circle"){
g.fill(this.rgb)
g.noStroke()
g.ellipse(this.x,this.y,this.size,this.size)
g.ellipse(this.x+(random(-7,-7)*-1*random(7)),(this.y+(random(-7,-7)*-1*random(7))),((this.size-random(-7,7))/2),((this.size-random(-7,7))/2))
  }
	if(mouseIsPressed && this.object == "rectangle"){
g.fill(this.rgb)
g.noStroke()
g.rect(this.x,this.y,this.size,this.size)
g.rect(this.x+(random(-7,-7)*-1*random(7)),(this.y+(random(-7,-7)*-1*random(7))),((this.size-random(-7,7))/2),((this.size-random(-7,7))/2))
	}
	if(mouseIsPressed && this.object == "triangle"){
g.fill(this.rgb)
g.noStroke()
g.triangle(this.x,this.y,this.x+this.size,this.y+this.size,this.x-this.size,this.y+this.size)
g.triangle(this.x+(random(-7,-7)*-1*random(7)),(this.y+(random(-7,-7)*-1*random(7)),((this.x+this.size-random(-7,7))/2),((this.y+this.size-random(-7,7))/2),((this.x-this.size-random(-7,7))/2)),((this.y+this.size-random(-7,7))/2))
	}
 }
}
