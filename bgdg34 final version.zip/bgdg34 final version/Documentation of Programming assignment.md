# Documentation of Programming assignment
# Bo Song

 My original code is like in a screen , you can draw colorful particles by moving your mouse. There is splashy effect at the same time.

 I have seperated my code into three parts, **particle.js**, **index.js**, and **particle.html**

### First part
The first part is **index.js** , in this part I made a class bubble , to make the code become a reusable component.

 ```
 class bubble{

constructor(colour,size,object){
this.x = mouseX
this.y = mouseY
this.size = size||random(50)
this.colour = colour ||"red"
this.object = object ||"circle"
 ```
 So the name of class is **bubble** , inside the **bubble** , the first part is a **constructor**,inside the **constructor** ,there are three parameters , called **colour** , **size** , **object**.

 These three things are the paramenter I want to be resuable , so people want to change them will be very easily.
- **X** refer the x position of object creates
- **Y** refer the y position of object creates
 And mouseX and mouseY means the objects will be created at where the mouse is.
 - **size** refer the size of the object
 - **random(50)** is its initial value , so the size of initial praticles vary from 0 to 50.
 - **colour** refer the value of color of the object
 - **"red"** is its initial value , it represents red series color.
 - **object** refer the shape of the object
- **circle** is its initial value , it represents the initial shape of the object is circle

 ```
 if (this.colour == "red"){
 this.r = 255
 this.ga = random(255)
 this.b = random(255)
 this.rgb = [this.r,this.ga,this.b]

}
if(this.colour == "blue"){
 this.r = random(255)
 this.ga = random(255)
 this.b = 255
 this.rgb = [this.r,this.ga,this.b]
}
if(this.colour == "green"){
 this.r = random(255)
 this.ga = 255
 this.b = random(255)
 this.rgb = [this.r,this.ga,this.b]
}
```
This is the part of code below the constructor.
This is a "color selector",in the html page there will be three buttons , each buttons will refer a different color series, but in the end , this.colour will become the value of the button you currently pressed, so if `this.colour == red`
- this.r refer the r value of rgb, because we want red series color, so the value of this.r = 255
- this.ga refer the g value of rgb , because we want red series color ,so the value of this.ga = random(255),to make different red series color.
- this.b refer the b value of rgb , because we want red series color ,so the value of this.b = random(255),to make different red series color.
- this.rgb is the combination of r,ga,b . It is like [255,255,255]
- So,the color of new particles will be red series color like orange red pink.
###### the other color works the same way...

```
setColour(colour){
 this.colour = colour

}
setSize(size){
 this.size = size
}
setObject(object){
 this.object = object
}
```
This is the next part of the code. There are three functions. And they are all **Set functions**. In the other page of code , we will use these codes , so at here we are just define these codes. In the html page ,we have 9 buttons which refer different values on **size**,**shape**,**color** of the object, so when we pressed the button , **this.value** need to be same as the value of button refers , **set** method is used to do that.
```
draw(g){

 if(mouseIsPressed && this.object == "circle"){
g.fill(this.rgb)
g.noStroke()
g.ellipse(this.x,this.y,this.size,this.size)
g.ellipse(this.x+(random(-7,-7)*-1*random(7)),(this.y+(random(-7,-7)*-1*random(7))),((this.size-random(-7,7))/2),((this.size-random(-7,7))/2))
 }
 if(mouseIsPressed && this.object == "rectangle"){
g.fill(this.rgb)
g.noStroke()
g.rect(this.x,this.y,this.size,this.size)
g.rect(this.x+(random(-7,-7)*-1*random(7)),(this.y+(random(-7,-7)*-1*random(7))),((this.size-random(-7,7))/2),((this.size-random(-7,7))/2))
 }
 if(mouseIsPressed && this.object == "triangle"){
g.fill(this.rgb)
g.noStroke()
g.triangle(this.x,this.y,this.x+this.size,this.y+this.size,this.x-this.size,this.y+this.size)
g.triangle(this.x+(random(-7,-7)*-1*random(7)),(this.y+(random(-7,-7)*-1*random(7)),((this.x+this.size-random(-7,7))/2),((this.y+this.size-random(-7,7))/2),((this.x-this.size-random(-7,7))/2)),((this.y+this.size-random(-7,7))/2))
 }
 }
```
- This is **draw** function base on the class **bubble**,
In the html page , there are three buttons refer **circle** , **rectangle** , **triangle** , and in this draw function , there are three **if** sentences , in the next page , there is a var called **globalobject** , by using set function , the value we choose by pressing the button will be firstly set to **globalobject** , then set as **this.object** , acoording to the value of this.object we can draw three different shape of objects.
- for example , we use this part
 ```
 if(mouseIsPressed && this.object == "circle"){
 g.fill(this.rgb)
 g.noStroke()
 g.ellipse(this.x,this.y,this.size,this.size)
 g.ellipse(this.x+(random(-7,-7)*-1*random(7)),(this.y+(random(-7,-7)*-1*random(7))),((this.size-random(-7,7))/2),((this.size-random(-7,7))/2))
 }
 ```
 so `this object == "circle"`, we will do the code below when we press the mouse. First we will fill the object with the color **this.rgb** ,which we have already set the value, then we have `noStroke()`,next we will draw two circles using function `ellipse()`,the first one is in the position of the mouse and the size we set. The second one ,have some random change based on the first one , so compare to first one, the position of the second one may be changed and the size of the second one can be changed , this is for the **splashy effect**.
 ##### The rest part of code work in the same way.

 ## Second part
 The second part is **particle.js** . In this part , I used a lot of functions to make the sketch and do the dom implementation.
 ```
 var g;
 var bubble1;
 var globalcolor = "red"
 var globalsize = Math.random()*50
 var globalobject = "circle"
 ```
 - these are the variables I defined in the **particle.js**
 - **g is a 3D Cube object**
 - **bubble1 is the sketch object**
 - **globalcolor is the variable which save the current color that I want,and the initial value of it is "red"**
 - **globalsize is the variable which save the current size that I want,and the initial value of it is random(50)**
 - **globalobject is the variable which save the current shape of the object that I want, and the initial value of it is "circle"**

```
function setup(){
pixelDensity(1)
createCanvas(800,600,WEBGL)
g = createGraphics(400,400)
g.background(255)
noStroke()
}
```
Now we start to build the sketch.
`function setup()` will do the things inside the function at the beginning, so it will only do once.
`pixelDensity()` is for sets the pixel scaling for high pixel density displays.
`createCanvas(800,600,WEBGL)` is to create a canvas to put our sketch in.
`g = createGraphics(400,400)` is to create a new 3D renderer object.
`g.background(255)` is to set the color of cube s background to white.
`noStroke` is to make there no stroke

```
function draw(){
bubble1 = new bubble(globalcolor,globalsize,globalobject)
bubble1.setColour(globalcolor)
bubble1.setSize(globalsize)
bubble1.setObject(globalobject)
background(100)
bubble1.draw(g)
rotateX(millis() / 1000);
rotateY(millis() / 1000*1.3);
rotateZ(millis() / 1000*0.7);
texture(g)
box(300)
}
```
`function draw()` is the function to make skectch, it will always be refreshed.
`bubble1 = new bubble(globalcolor,globalsize,globalobject)` It will create a new object using `class Bubble()`
```
bubble1.setColour(globalcolor)
bubble1.setSize(globalsize)
bubble1.setObject(globalobject)
```
These are three **set functions** ,and what they do is to make the global variables store the value we currently have.
`background(100)` set the background of the sketch to **gray**
`bubble1.draw(g)` is to use **draw function** in class Bubble , and draw on the renderer object.
```
rotateX(millis() / 1000);
rotateY(millis() / 1000*1.3);
rotateZ(millis() / 1000*0.7);
texture(g)
box(300)
```
This part of code creates a **box** or a **cube** as a 3D renderer object, and it keeps rotating, and put the box on the graphics we made previously.
```
document.addEventListener("DOMContentLoaded", function(){
 var buttonred = document.getElementById("redcolour")
 function changeColourred(event){
 globalcolor = "red"
 }
 buttonred.addEventListener("click",changeColourred)
 var buttonblue = document.getElementById("bluecolour")
 function changeColourblue(event){
 globalcolor = "blue"
 }
 buttonblue.addEventListener("click",changeColourblue)
 var buttongreen = document.getElementById("greencolour")
 function changeColourgreen(event){
 globalcolor = "green"
 }
 buttongreen.addEventListener("click",changeColourgreen)

 var buttonsmallsize = document.getElementById("smallsize")
 function changeSizesmall(event){
 globalsize = Math.random()*50
 }
 buttonsmallsize.addEventListener("click",changeSizesmall)

 var buttonmediumsize = document.getElementById("mediumsize")
 function changeSizemedium(event){
 globalsize = Math.random()*100+25
 }
 buttonmediumsize.addEventListener("click",changeSizemedium)

 var buttonbigsize = document.getElementById("bigsize")
 function changeSizebig(event){
 globalsize = Math.random()*150+50
 }
 buttonbigsize.addEventListener("click",changeSizebig)

 var drawcircle = document.getElementById("circle")
 function changeObjectcircle(event){
 globalobject = "circle"
 }
 drawcircle.addEventListener("click",changeObjectcircle)

 var drawrectangle = document.getElementById("rectangle")
 function changeObjectrectangle(event){
 globalobject = "rectangle"

 }
 drawrectangle.addEventListener("click",changeObjectrectangle)

 var drawtriangle = document.getElementById("triangle")
 function changeObjecttriangle(event){
 globalobject = "triangle"
 }
 drawtriangle.addEventListener("click",changeObjecttriangle)

 });
```
Finally this is our dom part. What this part of code so is to detect whether the button is pressed , and do the react - change value of global objects when the button is pressed.
```
document.addEventListener("DOMContentLoaded", function(){
 var buttonred = document.getElementById("redcolour")
 function changeColourred(event){
 globalcolor = "red"
 }
 buttonred.addEventListener("click",changeColourred)
```
Lets make the first part of code as an example.
`document.addEventListener("DOMContentLoaded", function(){` this line of code is to make sure the function can run only after all dom contents are loaded.
Then we have
`var buttonred = document.getElementById("redcolour")` **redcolour** is the buttons id I created in the html page. And there is the get function, get the value from the object whose id is**redcolour**
```
function changeColourred(event){
 globalcolor = "red"
 }
```
This function is refer to a change globalcolor to "red"
`buttonred.addEventListener("click",changeColourred)` This is the final magic, so for buttonred, when is been "clicked",changeColourred will work, so the global color will be changed to "red".
###### the other code works the same way...
## Final Part - HTML page
```
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/0.7.2/p5.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/0.7.2/addons/p5.dom.js"></script>
<script  type="text/javascript" src="index.js"></script>
<script  type="text/javascript" src="bubble.js"></script>

```
This part of code refers to the p5 library I used , and the other code file.
```

# Create you own colorful cube!
<button id = "redcolour">red series color</button>
<button id = "bluecolour">blue series color</button>
<button id = "greencolour">green series color</button>
<button id = "smallsize">small size</button>
<button id = "mediumsize">medium size</button>
<button id = "bigsize">big size</button>
<button id = "circle">circle</button>
<button id = "rectangle">rectangle</button>
<button id = "triangle">triangle</button>
Use color buttons to change the color series you want.

Use size buttons to change the size you want.

Use shape buttons to change the shape of the object you want.

 ```
 This part of code refers to the Instructions I gaved and the buttons I created. And the id is inside the button, and we can use `getElementById` to detect the value.
