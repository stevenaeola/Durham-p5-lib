var g;
var bubble1;
var globalcolor = "red"
var globalsize = Math.random()*50
var globalobject = "circle"
function setup(){
pixelDensity(1)
createCanvas(800,600,WEBGL)
g = createGraphics(400,400)
g.background(255)
noStroke()
}

function draw(){
bubble1 = new bubble(globalcolor,globalsize,globalobject)
bubble1.setColour(globalcolor)
bubble1.setSize(globalsize)
bubble1.setObject(globalobject)
background(100)
bubble1.draw(g)
rotateX(millis() / 1000);
rotateY(millis() / 1000*1.3);
rotateZ(millis() / 1000*0.7);
texture(g)
box(300)

}

document.addEventListener("DOMContentLoaded", function(){
    var buttonred = document.getElementById("redcolour")
    function changeColourred(event){
    globalcolor = "red"
  }
    buttonred.addEventListener("click",changeColourred)
    var buttonblue = document.getElementById("bluecolour")
    function changeColourblue(event){
    globalcolor = "blue"
  }
    buttonblue.addEventListener("click",changeColourblue)
    var buttongreen = document.getElementById("greencolour")
    function changeColourgreen(event){
    globalcolor = "green"
  }
    buttongreen.addEventListener("click",changeColourgreen)


    var buttonsmallsize = document.getElementById("smallsize")
    function changeSizesmall(event){
      globalsize = Math.random()*50
    }
    buttonsmallsize.addEventListener("click",changeSizesmall)

    var buttonmediumsize = document.getElementById("mediumsize")
    function changeSizemedium(event){
      globalsize = Math.random()*100+25
    }
    buttonmediumsize.addEventListener("click",changeSizemedium)

    var buttonbigsize = document.getElementById("bigsize")
    function changeSizebig(event){
      globalsize = Math.random()*150+50
    }
    buttonbigsize.addEventListener("click",changeSizebig)

    var drawcircle = document.getElementById("circle")
    function changeObjectcircle(event){
       globalobject = "circle"
    }
    drawcircle.addEventListener("click",changeObjectcircle)

    var drawrectangle = document.getElementById("rectangle")
    function changeObjectrectangle(event){
      globalobject = "rectangle"

    }
    drawrectangle.addEventListener("click",changeObjectrectangle)

    var drawtriangle = document.getElementById("triangle")
    function changeObjecttriangle(event){
      globalobject = "triangle"
    }
    drawtriangle.addEventListener("click",changeObjecttriangle)


  });
