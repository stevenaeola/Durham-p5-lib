## License
 The code is based on "junckier" s work - Colorful Trip (https://www.openprocessing.org/sketch/628358) which is on openprocessing.org
 The license is **Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)**
 More Information:https://creativecommons.org/licenses/by-sa/3.0/
 **Free to share and adapt**


