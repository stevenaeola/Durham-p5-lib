class Points {
	constructor(repval, x, y, font, fontSize, stWeight, cannotBeUpdated, colour, maxSPEED) {
		this.fontSize = fontSize;
		this.stWeight = stWeight;
		this.RepresentedVal = repval;
		this.font = font;
		this.bounds = font.textBounds(this.RepresentedVal, 0, 0, this.fontSize);
		this.locX = x;
		this.locY = y;
		this.cannotBeUpdated = cannotBeUpdated;
		this.points = this.font.textToPoints(repval, this.locX, this.locY, this.fontSize, {sampleFactor: 0.1});
		this.PointsObjects = [];
		for (var i = 0; i < this.points.length; i++) {
			var pt = this.points[i];
			this.PointsObjects[i] = new Vehicle(pt.x, pt.y, this.stWeight, colour, maxSPEED);
		}
	}

	updateText(newText) {

		if (!this.cannotBeUpdated) {
			this.RepresentedVal = newText;
			// this.bounds = this.font.textBounds(this.RepresentedVal, 0, 0, this.fontSize);

			this.points = this.font.textToPoints(this.RepresentedVal, this.locX, this.locY, this.fontSize);

			if (this.points.length < this.PointsObjects.length) {        // if there are more points than vehicles before
				var toSplice = this.PointsObjects.length - this.points.length;
				this.PointsObjects.splice(this.points.length - 1, toSplice);     // cuts all the excess vector points

				for (var i = 0; i < this.points.length; i++) {
					this.PointsObjects[i].target.x = this.points[i].x;
					this.PointsObjects[i].target.y = this.points[i].y;

					var force = p5.Vector.random2D();
					force.mult(random(0));
					this.PointsObjects[i].applyForce(force);
				}
			} else if (this.points.length > this.PointsObjects.length) {  // we now need to create some more points as the new value needs more

				for (var i = this.PointsObjects.length; i < this.points.length; i++) {
					var v = this.PointsObjects[i - 1].clone();        // we clone previous points and assign them values later
					this.PointsObjects.push(v);
				}

				for (var i = 0; i < this.points.length; i++) {
					this.PointsObjects[i].target.x = this.points[i].x;
					this.PointsObjects[i].target.y = this.points[i].y;

					var force = p5.Vector.random2D();
					force.mult(random(0));
					this.PointsObjects[i].applyForce(force);
				}

			} else {
				for (var i = 0; i < this.points.length; i++) {
					this.PointsObjects[i].target.x = this.points[i].x;
					this.PointsObjects[i].target.y = this.points[i].y;

					var force = p5.Vector.random2D();
					force.mult(random(0));
					this.PointsObjects[i].applyForce(force);
				}
			}
		}
	}

	updateColour(colour) {
		for (var i = 0; i < this.PointsObjects.length; i++) {
			this.PointsObjects[i].color = colour;
		}
	}


	display() {
		for (var i = 0; i < this.points.length; i++) {
			this.PointsObjects[i].behaviors();
			this.PointsObjects[i].update();
			this.PointsObjects[i].show();
		}
	}
}

class Vehicle {
	constructor(x, y, size, colour, maxSPEED) {

		this.pos = createVector(random(width), random(height));
		this.target = createVector(x, y);
		this.vel = p5.Vector.random2D();
		this.acc = createVector();
		this.maxspeed = maxSPEED;
		this.maxforce = 1;
		this.color = colour;
		this.r = size;


	}

	behaviors() {
		var arrive = this.arrive(this.target);
		this.acc.add(arrive);
	}

	applyForce(f) {
		this.acc.add(f);
	}

	update() {
		this.pos.add(this.vel);
		this.vel.add(this.acc);
		this.acc.mult(0);
	}

	show() {

		stroke(this.color[0], this.color[1], this.color[2]);
		strokeWeight(this.r);
		point(this.pos.x, this.pos.y);

	}

	arrive(target) {
		var desired = p5.Vector.sub(target, this.pos);
		var d = desired.mag();
		var speed = this.maxspeed;
		if (d < 100) {
			speed = map(d, 0, 100, 0, this.maxspeed);
		}
		desired.setMag(speed);
		var steer = p5.Vector.sub(desired, this.vel);
		steer.limit(this.maxforce);
		return steer;
	}

	flee(target) {
		var desired = p5.Vector.sub(target, this.pos);
		var d = desired.mag();
		if (d < 50) {
			desired.setMag(this.maxspeed);
			desired.mult(-1);
			var steer = p5.Vector.sub(desired, this.vel);
			steer.limit(this.maxforce);
			return steer;
		} else {
			return createVector(0, 0);
		}

	}

	clone() {
		var v = new Vehicle(this.pos.x, this.pos.y, this.r, this.maxspeed);

		v.pos.x = this.pos.x;
		v.pos.y = this.pos.y;

		v.color = this.color;
		v.r = this.r;
		v.maxspeed = this.maxspeed;

		v.vel.x = this.vel.x;
		v.vel.y = this.vel.y;

		v.acc.x = this.acc.x;
		v.acc.y = this.acc.y;

		return v;
	}
}

var font;
var sudokuValues = [];
var displaySudoku = [];
var actualSudoku = [1, 2, 3, 6, 9, 8, 5, 4, 7, 4, 5, 6, 7, 1, 3, 8, 9, 2, 7, 8, 9, 5, 2, 4, 3, 6, 1, 2, 7, 5, 1, 3, 6, 4, 8, 9, 3, 9, 1, 8, 4, 7, 6, 2, 5, 6, 4, 8, 9, 5, 2, 1, 7, 3, 9, 3, 4, 2, 8, 5, 7, 1, 6, 5, 6, 2, 4, 7, 1, 9, 3, 8, 8, 1, 7, 3, 6, 9, 2, 5, 4];
var completedArr = [];
var completeText = "Well-Done!";
var completeIndi = false; //this is because there are already too many processes that slow down the animation.


function sudokuTable() {

	// shuffles vertical sets
	let shift1 = int(random(3));
	let shift2 = int(random(3));
	let shift3 = int(random(3));
	while (shift2 == shift1) {
		shift2 = int(random(2));
	}
	while ((shift3 == shift1) || (shift3 == shift2)) {
		shift3 = int(random(2));
	}
	shift1 = actualSudoku.slice((shift1 * 27), (shift1 * 27) + 27);
	shift2 = actualSudoku.slice((shift2 * 27), (shift2 * 27) + 27);
	shift3 = actualSudoku.slice((shift3 * 27), (shift3 * 27) + 27);
	actualSudoku = [];
	actualSudoku = actualSudoku.concat(shift1, shift2, shift3);

	// shuffles horizontal sets

	shift1 = int(random(3));
	shift2 = int(random(3));
	shift3 = int(random(3));
	while (shift2 == shift1) {
		shift2 = int(random(2));
	}
	while ((shift3 == shift1) || (shift3 == shift2)) {
		shift3 = int(random(2));
	}

	let shift_temp = shift1;
	shift1 = [];
	for (var x = shift_temp * 3; x < ((shift_temp * 3) + 81); x += 9) {
		shift1 = shift1.concat(actualSudoku.slice(x, (x + 3)));
	}
	shift_temp = shift2;
	shift2 = [];
	for (var x = shift_temp * 3; x < ((shift_temp * 3) + 81); x += 9) {
		shift2 = shift2.concat(actualSudoku.slice(x, (x + 3)));
	}
	shift_temp = shift3;
	shift3 = [];
	for (var x = shift_temp * 3; x < ((shift_temp * 3) + 81); x += 9) {
		shift3 = shift3.concat(actualSudoku.slice(x, (x + 3)));
	}

	actualSudoku = [];
	for (var i = 0; i < 81; i += 3) {
		actualSudoku = actualSudoku.concat(shift1.slice(i, (i + 3)));
		actualSudoku = actualSudoku.concat(shift2.slice(i, (i + 3)));
		actualSudoku = actualSudoku.concat(shift3.slice(i, (i + 3)));
	}

	for (var i = 0; i < actualSudoku.length; i++) {
		sudokuValues[i] = actualSudoku[i];
	}

	for (var i = 0; i < 53; i++) {
		let x = int(random(81));
		if (sudokuValues[x] != 0) {
			sudokuValues[x] = 0;
		} else {
			i--;
		}
	}
}

function checkIfcomplete() {
	if (!completeIndi) {
		for (var i = 0; i < actualSudoku.length; i++) {
			if (actualSudoku[i] != sudokuValues) {
				completeIndi = false;
				return false;
			}
		}
		if (!completeIndi) {
			completeIndi = true;
			return true;
		}
	}
}

function preload() {
	font = loadFont("Fonts/AvenirNextLTPro-Demi.otf");
}

function setup() {

	createCanvas(windowWidth, windowHeight);
	background(51);

	let xcount = (windowWidth / 2) - 400;
	let ycount = (windowHeight / 2) - 400;
	let updatability = false;
	let weight = 6;

	sudokuTable();
	for (var i = 0; i < 81; i++) {

		if (sudokuValues[i] == 0) {
			updatability = false;
			weight = 6;
		} else {
			updatability = true;
			weight = 8;
		}

		let xx = new Points(sudokuValues[i].toString(), xcount, ycount, font, 100, weight, updatability, [250, 250, 250], 20);
		displaySudoku.push(xx);
		decideColours(i);
		displaySudoku[i].updateText(sudokuValues[i].toString());
		xcount = xcount + 100;

		if ((((i + 1) % 9) == 0) && (i != 0) && (i != 79) || (i == 8)) {
			xcount = (windowWidth / 2) - 400;
			ycount = ycount + 100;
		}

	}

	xcount = 100;
	ycount = 500;
	updatability = true;
	weight = 6;


	for (var i = 0; i < completeText.length; i++) {


		xx = new Points(completeText[i], xcount, ycount, font, 200, weight, updatability, [250, 0, 0], 20);
		completedArr.push(xx);
		completedArr[i].updateText(completedArr[i]);
		xcount += 100;
	}

	showGrid();
}

function decideColours(i) {
	let z = map(displaySudoku[i].RepresentedVal, 0, 9, 0, 225);
	let temp = [z * 2, map(z, 0, 250, 100, 120), z * 0.75];
	displaySudoku[i].updateColour(temp);
}

function showGrid() {


	for (var x = 0; x < 10; x++) {
		let red = 250;
		let green = 0;
		if (x == 0 || x == 3 || x == 6 || x == 9) {
			green = 250;
			red = 0;
		}
		for (var i = (height / 2 - 485); i < (height / 2 - 485 + 900); i += 10) {
			strokeWeight(4);
			stroke(red, green, 0);
			point((((width / 2) - 410) + 99 * x), i);
		}
	}
	for (var x = 0; x < 10; x++) {
		let red = 250;
		let green = 0;
		if (x == 0 || x == 3 || x == 6 || x == 9) {
			green = 250;
			red = 0;
		}
		for (var i = ((width / 2) - 410); i < ((width / 2) - 400 + 880); i += 10) {
			strokeWeight(4);
			stroke(red, green, 0);
			point(i, ((height / 2 - 488) + 100 * x));
		}
	}

}

function mousePressed() {

	for (var iii = 0; iii < sudokuValues.length; iii++) {
		if (((mouseX > displaySudoku[iii].locX) && (mouseX < displaySudoku[iii].locX + 60)) && (!displaySudoku[[iii]].cannotBeUpdated) &&
			((mouseY < displaySudoku[iii].locY + 10) && (mouseY > displaySudoku[iii].locY - 90))) {
			sudokuValues[iii] = (sudokuValues[iii] % 9) + 1;
			displaySudoku[iii].RepresentedVal = sudokuValues[iii].toString();
			decideColours(iii);
			displaySudoku[iii].updateText(displaySudoku[iii].RepresentedVal);
		}
	}
	checkIfcomplete();
}

function draw() {

	if (!completeIndi) {
		background(51);
		showGrid();

		for (var ii = 0; ii < sudokuValues.length; ii++) {

			if (sudokuValues[ii] != 0) {
				displaySudoku[ii].display();
			}
		}
	} else {

		background(51);
		for (var ii = 0; ii < completedArr.length; ii++) {
			completedArr[ii].display();

		}
	}
}
