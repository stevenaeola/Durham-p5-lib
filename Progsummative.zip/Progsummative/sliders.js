var redSlider;
var greenSlider;
var blueSlider;
var radiusSlider;
var speedSlider;
var characterSlider;
var fontSizeSlider;
var fontSlider;
var lockSlider;

var repval = "H";
var updatability = false;
var redRGB = 250;
var greenRGB = 250;
var blueRGB = 250;
var locX = 100;
var locY = 380;
var maximumVel = 10;
var fontSize = 440;
var weight = 6;

var fonta;
var font1;
var font2;
var font3;

var aPoint;
var canvaas;

class Points {
	constructor(repval, x, y, font, fontSize, stWeight, cannotBeUpdated, colour, maxSPEED) {
		this.fontSize = fontSize;
		this.stWeight = stWeight;
		this.RepresentedVal = repval;
		this.font = font;
		this.bounds = font.textBounds(this.RepresentedVal, 0, 0, this.fontSize);
		this.locX = x;
		this.locY = y;
		this.cannotBeUpdated = cannotBeUpdated;
		this.points = this.font.textToPoints(repval, this.locX, this.locY, this.fontSize, {sampleFactor: 0.1});
		this.PointsObjects = [];
		for (var i = 0; i < this.points.length; i++) {
			var pt = this.points[i];
			this.PointsObjects[i] = new Vehicle(pt.x, pt.y, this.stWeight, colour, maxSPEED);
		}
	}

	updateText(newText) {

		if (!this.cannotBeUpdated) {
			this.RepresentedVal = newText;
			// this.bounds = this.font.textBounds(this.RepresentedVal, 0, 0, this.fontSize);

			this.points = this.font.textToPoints(this.RepresentedVal, this.locX, this.locY, this.fontSize);

			if (this.points.length < this.PointsObjects.length) {        // if there are more points than vehicles before
				var toSplice = this.PointsObjects.length - this.points.length;
				this.PointsObjects.splice(this.points.length - 1, toSplice);     // cuts all the excess vector points

				for (var i = 0; i < this.points.length; i++) {
					this.PointsObjects[i].target.x = this.points[i].x;
					this.PointsObjects[i].target.y = this.points[i].y;

					var force = p5.Vector.random2D();
					force.mult(random(0));
					this.PointsObjects[i].applyForce(force);
				}
			} else if (this.points.length > this.PointsObjects.length) {  // we now need to create some more points as the new value needs more

				for (var i = this.PointsObjects.length; i < this.points.length; i++) {
					var v = this.PointsObjects[i - 1].clone();        // we clone previous points and assign them values later
					this.PointsObjects.push(v);
				}

				for (var i = 0; i < this.points.length; i++) {
					this.PointsObjects[i].target.x = this.points[i].x;
					this.PointsObjects[i].target.y = this.points[i].y;

					var force = p5.Vector.random2D();
					force.mult(random(0));
					this.PointsObjects[i].applyForce(force);
				}

			} else {
				for (var i = 0; i < this.points.length; i++) {
					this.PointsObjects[i].target.x = this.points[i].x;
					this.PointsObjects[i].target.y = this.points[i].y;

					var force = p5.Vector.random2D();
					force.mult(random(0));
					this.PointsObjects[i].applyForce(force);
				}
			}
		}
	}

	updateColour(colour) {
		for (var i = 0; i < this.PointsObjects.length; i++) {
			this.PointsObjects[i].color = colour;
		}
	}


	display() {
		for (var i = 0; i < this.points.length; i++) {
			this.PointsObjects[i].behaviors();
			this.PointsObjects[i].update();
			this.PointsObjects[i].show()
		}
	}
}

class Vehicle {
	constructor(x, y, size, colour, maxSPEED) {

		this.pos = createVector(random(width), random(height));
		this.target = createVector(x, y);
		this.vel = p5.Vector.random2D();
		this.acc = createVector();
		this.maxspeed = maxSPEED;
		this.maxforce = 1;
		this.color = colour;
		this.r = size;


	}

	behaviors() {
		var arrive = this.arrive(this.target);
		this.acc.add(arrive);
	}

	applyForce(f) {
		this.acc.add(f);
	}

	update() {
		this.pos.add(this.vel);
		this.vel.add(this.acc);
		this.acc.mult(0);
	}

	show() {

		stroke(this.color[0], this.color[1], this.color[2]);
		strokeWeight(this.r);
		point(this.pos.x, this.pos.y);

	}

	arrive(target) {
		var desired = p5.Vector.sub(target, this.pos);
		var d = desired.mag();
		var speed = this.maxspeed;
		if (d < 100) {
			speed = map(d, 0, 100, 0, this.maxspeed);
		}
		desired.setMag(speed);
		var steer = p5.Vector.sub(desired, this.vel);
		steer.limit(this.maxforce);
		return steer;
	}

	flee(target) {
		var desired = p5.Vector.sub(target, this.pos);
		var d = desired.mag();
		if (d < 50) {
			desired.setMag(this.maxspeed);
			desired.mult(-1);
			var steer = p5.Vector.sub(desired, this.vel);
			steer.limit(this.maxforce);
			return steer;
		} else {
			return createVector(0, 0);
		}

	}

	clone() {
		var v = new Vehicle(this.pos.x, this.pos.y, this.r, this.maxspeed);

		v.pos.x = this.pos.x;
		v.pos.y = this.pos.y;

		v.color = this.color;
		v.r = this.r;
		v.maxspeed = this.maxspeed;

		v.vel.x = this.vel.x;
		v.vel.y = this.vel.y;

		v.acc.x = this.acc.x;
		v.acc.y = this.acc.y;

		return v;
	}
}

function preload() {
	font1 = loadFont('Fonts/AvenirNextLTPro-Demi.otf');
	font2 = loadFont('Fonts/Comfortaa-Bold.ttf');
	font3 = loadFont(`Fonts/Exo-ExtraBold.otf`);
	fonta = font1;
}

function setup() {
	canvaas = createCanvas(500, 550);
	canvaas.parent("sketch-holder");

	background(50);
	lockSlider = document.getElementById("LOCK");
	lockSlider.oninput = function () {
		if (int(this.value) == 1) {
			updatability = false;
			whichfont();
			repval = String.fromCharCode(int(characterSlider.value));
			redRGB = int(redSlider.value);
			greenRGB = int(greenSlider.value);
			blueRGB = int(blueSlider.value);
			maximumVel = int(speedSlider.value);
			fontSize = int(fontSizeSlider.value);
			weight = int(radiusSlider.value);
			aPoint = new Points(repval, locX, locY, fonta, fontSize, weight, updatability, [redRGB, greenRGB, blueRGB], maximumVel);
		} else if (int(this.value) == 2) {
			updatability = true;
			aPoint.cannotBeUpdated = true;
		}
	};
	redSlider = document.getElementById("RED");
	redSlider.oninput = function () {
		if (!updatability) {
			redRGB = int(this.value);
			aPoint.updateColour([redRGB, greenRGB, blueRGB]);
		}
	};
	greenSlider = document.getElementById("GREEN");
	greenSlider.oninput = function () {
		if (!updatability) {
			greenRGB = int(this.value);
			aPoint.updateColour([redRGB, greenRGB, blueRGB]);
		}
	};
	blueSlider = document.getElementById("BLUE");
	blueSlider.oninput = function () {
		if (!updatability) {
			blueRGB = int(this.value);
			aPoint.updateColour([redRGB, greenRGB, blueRGB]);
		}
	};
	radiusSlider = document.getElementById("RADIUS");
	radiusSlider.oninput = function () {
		if (!updatability) {
			weight = int(this.value);
			aPoint = new Points(repval, locX, locY, fonta, fontSize, weight, updatability, [redRGB, greenRGB, blueRGB], maximumVel);
		}
	};
	speedSlider = document.getElementById("MAXSPEED");
	speedSlider.oninput = function () {
		if (!updatability) {
			maximumVel = int(this.value);
			aPoint.maxSPEED = int(this.value);
		}
	};
	characterSlider = document.getElementById("ASCII");
	characterSlider.oninput = function () {
		repval = String.fromCharCode(int(this.value));
		aPoint.updateText(repval)
	};
	fontSizeSlider = document.getElementById("FONTSIZE");
	fontSizeSlider.oninput = function () {
		if (!updatability) {
			fontSize = int(this.value);
			aPoint = new Points(repval, locX, locY, fonta, fontSize, weight, updatability, [redRGB, greenRGB, blueRGB], maximumVel);
		}
	};
	fontSlider = document.getElementById("FONT");
	fontSlider.oninput = function () {
		if (!updatability) {
			whichfont();
			aPoint = new Points(repval, locX, locY, fonta, fontSize, weight, updatability, [redRGB, greenRGB, blueRGB], maximumVel);
		}
	};
	aPoint = new Points(repval, locX, locY, fonta, fontSize, weight, updatability, [redRGB, greenRGB, blueRGB], maximumVel);
}

function whichfont() {

	if ((int(fontSlider.value)) === 1) {
		fonta = font1;
	} else if ((int(fontSlider.value)) === 2) {
		fonta = font2;
	} else if ((int(fontSlider.value)) === 3) {
		fonta = font3;
	}

}

function draw() {
	background(51);
	aPoint.display();
}
