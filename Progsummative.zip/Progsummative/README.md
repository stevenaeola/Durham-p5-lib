descriptorsproperties# VQWH89
## [Adaptation of the particle clock](https://www.openprocessing.org/sketch/631242)
A extension of Daniel Shiffmans particle Text as a Clock...

My adaptation takes the textToPoints function in p5js, and then applies the steering behaviours in the original sketch to adapt it into a Sudoku player. There are two HTML files to look at, check out ObjectIllustration.html to see how the object Points has been implemented, and SudokuPlayer.html for my adaptation of the original sketch.

# PLEASE NOTE WHEN TESTING, DO NOT USE THE CHROME BROWSER, chrome will not let non-HTTPS HTML documents import locally stored otf files as a malware protection feature.
## THIS IS NOT AN ECMA 6 NON-COMPLIANCE ISSUE AS THIS IS A FUNDAMENTAL LIMITATION OF THE BROSWER. even using CSS to import the font didn't work for me in testing; please use edge or safari.

A separate class Points which stores a range of parameters about the points, relating to their colour, size, stroke weight and whether or the represented value can be updated.

# Class Points
## constructor

```javascript
constructor(repval,x,y,font,fontSize,stWeight,cannotBeUpdated,colour,maxSPEED) {
  this.fontSize = fontSize;
  this.stWeight = stWeight;
  this.RepresentedVal = repval;
  this.bounds = font.textBounds(this.RepresentedVal, 0, 0, this.fontSize);
  this.locX = x;  
  this.locY = y;  
  this.cannotBeUpdated = cannotBeUpdated;
  this.points = font.textToPoints(this.RepresentedVal, this.locX, this.locY, this.fontSize, {sampleFactor: 0.1});
  this.PointsObjects = [];


  for (var i = 0; i < this.points.length; i++) {
    var pt = this.points[i];
    this.PointsObjects[i] = new Vehicle(pt.x,pt.y,this.stWeight,colour,maxSPEED);
  }
}
```

Code Extract 1

The purpose of this Whole class is to store the collection of points that make up the represented letter or `this.RepresentedVal`, and the algorithms involved with displaying the object on the canvas. there are 4 functions in this class including the constructor.

``` javascript  
this.points = font.textToPoints(this.RepresentedVal, this.locX, this.locY, this.fontSize, {sampleFactor: 0.1});
```
Code Extract 2
the funtion `font.textToPoints` takes the character represented by `this.RepresentedVal` and splits it into a set of points along the contours of the character in the stated font and the stated size, starting at a given (x,y) coordinate. This function is native in the p5.js library .

the constructor will generate a set of "Vehicles" which are essentially the points that make up the letters, they are further defined as objects of class Vehicle, which then gives these points a range of behaviours and properties.

## Update text function

``` javascript

1. updateText(newText) {

2.  if (!this.cannotBeUpdated){
3.    this.RepresentedVal = newText;
4.      this.bounds = font.textBounds(this.RepresentedVal, 0, 0, this.fontSize);
5.
6.      this.points = font.textToPoints(this.RepresentedVal, this.locX, this.locY, this.fontSize);
7.      if (this.points.length < this.PointsObjects.length) {        // if there are more points than vehicles before
8.          var toSplice = this.PointsObjects.length - this.points.length;
9.          this.PointsObjects.splice(this.points.length - 1, toSplice);     // cuts all the excess vector points
10.          for (var i = 0; i < this.points.length; i++) {
11.              this.PointsObjects[i].target.x = this.points[i].x;
12.              this.PointsObjects[i].target.y = this.points[i].y;
13.
14.              var force = p5.Vector.random2D();
15.              force.mult(random(0));
16.              this.PointsObjects[i].applyForce(force);
17.          }
18.      } else if (this.points.length > this.PointsObjects.length) {  // we now need to create some more points as the new value needs more
19.          for (var i = this.PointsObjects.length; i < this.points.length; i++) {
20.              var v = this.PointsObjects[i - 1].clone();        // we clone previous points and assign them values later
21.              this.PointsObjects.push(v);
22.          }
23.          for (var i = 0; i < this.points.length; i++) {
24.              this.PointsObjects[i].target.x = this.points[i].x;
25.              this.PointsObjects[i].target.y = this.points[i].y;
26.              var force = p5.Vector.random2D();
27.              force.mult(random(0));
28.              this.PointsObjects[i].applyForce(force);
29.          }
30.      } else {
31.          for (var i = 0; i < this.points.length; i++) {
32.              this.PointsObjects[i].target.x = this.points[i].x;
33.              this.PointsObjects[i].target.y = this.points[i].y;
34.              var force = p5.Vector.random2D();
35.              force.mult(random(0));
36.              this.PointsObjects[i].applyForce(force);
37.          }
38.      }
39.  }
40.}

```

Code Extract 3

This function is responsible for changing the value of `this.RepresentedVal`, and all the changes to the array of Vehicles that are responsible for displaying the points on the screen. It starts with testing `2.  if (!this.cannotBeUpdated){` which assesses whether or not the object `Points` can have it's represented value changed.
`this.points = font.textToPoints(this.RepresentedVal, this.locX, this.locY, this.fontSize);`
Code Extract 3.1
There are three possible scenarios in this function, this is where `this.points` has a greater number of points than the number of points representing the previous character. Or there were fewer points prior, or the previous number of points is equal to the new number of points.

``` javascript
7.      if (this.points.length < this.PointsObjects.length) {        // if there are more points than vehicles before
8.          var toSplice = this.PointsObjects.length - this.points.length;
9.          this.PointsObjects.splice(this.points.length - 1, toSplice);     // cuts all the excess vector points
10.          for (var i = 0; i < this.points.length; i++) {
11.              this.PointsObjects[i].target.x = this.points[i].x;
12.              this.PointsObjects[i].target.y = this.points[i].y;
13.
14.              var force = p5.Vector.random2D();
15.              force.mult(random(0));
16.              this.PointsObjects[i].applyForce(force);
17.          }
18.      }
```
Code Extract 3.2

This is the first of the aforementioned scenarios.
Line 8 will calculate the excess number of points that will need to be spliced (i.e. removed). Line 9 will then remove the excess points, A loop is started on line 10 which will set the Vehicles x and y points where the Vehicles should be placed, in order to show the new character.

Line 14 - 15 will create a negative force which will then be applied to the Vehicles which will create an animation when the Vehicles are later displayed. Line 16 will apply the force to the Vehicles.

``` javascript
18 else if (this.points.length > this.PointsObjects.length) {  // we now need to create some more points as the new value needs more
19.          for (var i = this.PointsObjects.length; i < this.points.length; i++) {
20.              var v = this.PointsObjects[i - 1].clone();        // we clone previous points and assign them values later
21.              this.PointsObjects.push(v);
22.          }
23.          for (var i = 0; i < this.points.length; i++) {
24.              this.PointsObjects[i].target.x = this.points[i].x;
25.              this.PointsObjects[i].target.y = this.points[i].y;
26.              var force = p5.Vector.random2D();
27.              force.mult(random(0));
28.              this.PointsObjects[i].applyForce(force);
29.          }
30.      }
```
Code Extract 3.2

This is the second scenarios where there are not enough previously created Vehicles to display the new character. A loop is started on line 19, That will clone previously generated Vehicles, instead of creating new ones, this saves time compared to constructing new Vehicles, this will also create an interesting animation as it appears like the Vehicles emerge from the same location. line 21 will the store the cloned Vehicle Object.

Lines 23 - 28 serve the same purpose as 10-16 (in Extract 3.1).

``` javascript
30.       else {
31.          for (var i = 0; i < this.points.length; i++) {
32.              this.PointsObjects[i].target.x = this.points[i].x;
33.              this.PointsObjects[i].target.y = this.points[i].y;
34.              var force = p5.Vector.random2D();
35.              force.mult(random(0));
36.              this.PointsObjects[i].applyForce(force);
37.          }
38.      }
```
Code Extract 3.3

This is the third scenarios where there are an equal number of points as there were prior, this loop serves the same purpose as lines 23-28 and 10-16. And will thusly simply update the coordinates for all the vehicles, and apply a negative force to them.


## Colour update function
``` javascript
updateColour(colour){
  for (var i = 0; i < this.PointsObjects.length; i++) {
    this.PointsObjects[i].color = colour;
  }
}
```
Code Extract 4

This Function is responsible for updating the RGB value for the Vehicles stored in `this.PointsObjects` by the parameter given `colour`.


## Display function

``` javascript
display(){
    for (var i = 0; i < this.points.length; i++) {
       this.PointsObjects[i].behaviors()
       this.PointsObjects[i].update()
       this.PointsObjects[i].show()
    }
  }
```
Code Extract 5

This Function is responsible for Drawing the Vehicles onto the canvas. As you will later see, the Vehicles are given random vectors and a destination point, and therefore in order to animate the points arriving at their destinations A range of functions need to be called for each vehicle used to show the character on the canvas. These functions are `behaviors()` , `update()` and `show()`. The display function will later be called on the p5 Draw function.

# Class Vehicles
## Constructor Function

``` javascript
constructor(x, y, size, colour,maxSPEED) {

  this.pos = createVector(random(width), random(height));
  this.target = createVector(x, y);
  this.vel = p5.Vector.random2D();
  this.acc = createVector();
  this.maxspeed = maxSPEED;
  this.maxforce =1;
  this.color = colour;
  this.r = size;

}
```

Code Extract 6

There are 7 stored properties for every instance of the class. `this.pos` is a vector which when the object is constructed is a pair of random coordinates which will later travel to their destinations. `this.target` is the coordinate where the vehicle should travel that will later display the desired character. `this.vel` is a random magnitude and direction. `this.acc` will represent the vehicle's acceleration and will later be defined. ` this.maxspeed` is a variable which will vary the speed at which the Vehicle will arrive at the target, Increasing the speed will increase the time taken to arrive as there will be more animation of the vehicle before it arrives. `this.maxforce` will be used to prevent the randomly generated force from preventing the vehicle arriving at the destination.
`this.color` will represent the RGB value of the point. `this.r` will later be used as the strokeWeight of the points drawn.

## Behaviour Function

``` javascript
behaviors(){
var arrive = this.arrive(this.target);
this.acc.add(arrive);
}
```
Code Extract 7

This function is used as an intermediary for the function `this.arrive(target)`. However what this essentially does is take a force generated by the function `this.arrive(target)` and then carries out the function adds this value to the acceleration, this is simply building up the acceleration of the vehicle by the amount determined by `this.arrive(target)`.


## applyForce function

``` javascript
applyForce(f){
  this.acc.add(f);
}
```
Code Extract 8
This is a very basic function which increments the acceleration of the Vehicle by a given argument `f`. There will be times where this used as a function will become useful.

## update function

```javascript
update(){
  this.pos.add(this.vel);
  this.vel.add(this.acc);
  this.acc.mult(0);
}
```
Code Extract 9

This function will change the x,y position of the vehicle by the speed vector and will increase the velocity by the acceleration vector, and then reset the acceleration vector to 0, this is so that the Vehicle doesn't continue to accelerate at an uncontrolled rate but rather, increase it by a given amount in some other dedicated functions.

## Show function
``` javascript
show(){

stroke(this.color[0],this.color[1],this.color[2]);
strokeWeight(this.r);
point(this.pos.x, this.pos.y);

}
```
Code Extract 10

This fucntion is responsible for drawing the Vehicle on the screen, `this.color` is an array storing the Red,Green and Blue RGB vales in separate indices. strokeWeight is defined as `this.r` (see constructor for more) and a point is drawn at the x,y location indicated by `this.pos` which is a vector. Obviously Any kind of shape could be drawn whether they are in the p5js library or not; however I have opted for a point like the original programmer.

## arrive Function

``` javascript
arrive(target){
var desired = p5.Vector.sub(target, this.pos);
var d = desired.mag();
var speed = this.maxspeed;
if (d < 100) {
    speed = map(d, 0, 100, 0, this.maxspeed);
}
desired.setMag(speed);
var steer = p5.Vector.sub(desired, this.vel);
steer.limit(this.maxforce);
return steer;
}
```

Code Extract 11

This function makes use of Newtonian mechanics steering forces, create a force which will then be applied to the vehicle to arrive at a desired speed. Briefly, the vectors `target` and `this.pos` are subtracted and direction is ignored, if the value is greater than 100 pixles/unit time the value is mapped between 0 and `this.maxspeed` (10), otherwise it is simply set to 10, the steering force is calculated as a vector subtraction of the value calculated from the current velocity, and limited to `this.maxforce`(1). The calculated steering force is then returned.

## flee function
``` javascript
flee(target){
var desired = p5.Vector.sub(target, this.pos);
var d = desired.mag();
if (d < 50) {
    desired.setMag(this.maxspeed);
    desired.mult(-1);
    var steer = p5.Vector.sub(desired, this.vel);
    steer.limit(this.maxforce);
    return steer;
} else {
    return createVector(0, 0);
}

}dd
```
Code Extract 12

This function is not made use of in my implementation as the whole purpose of this is to create a force which avoids another object. In the original code the Vehicles would avoid mouseX and mouseY. In my implementation mouseX and mouseY are used to increment the represented values, and implementing the flee mechanics would make the game unusable.

However what this code essentially does is the same as the arrive function, the only differences are that the vehicles are applied a steering force in the opposite direction from where they should be, and the distance from which the Vehicle must be within for the acceleration to be increased by is 50 pixels.

## clone Function

``` javascript
  clone(){
  var v = new Vehicle(this.pos.x, this.pos.y);

  v.pos.x = this.pos.x;
  v.pos.y = this.pos.y;

  v.color = this.color

  v.vel.x = this.vel.x;
  v.vel.y = this.vel.y;

  v.acc.x = this.acc.x;
  v.acc.y = this.acc.y;

  return v;
}
}
```

Code Extract 13

This function is used create new vehicles with the same attributes as the current Vehicle, this function is made use of when the value for `this.RepresentedVal` in the Points class. See Code Extract 3.2 for more information.

# Global Variables

``` javascript
var font;
var sudokuValues = [];
var displaySudoku = [];
var actualSudoku = [1,2,3,6,9,8,5,4,7,4,5,6,7,1,3,8,9,2,7,8,9,5,2,4,3,6,1,2,7,5,1,3,6,4,8,9,3,9,1,8,4,7,6,2,5,6,4,8,9,5,2,1,7,3,9,3,4,2,8,5,7,1,6,5,6,2,4,7,1,9,3,8,8,1,7,3,6,9,2,5,4];
var completedArr = []
var completeText = "Well-Done!";
var completeIndi = false;
```
Code Extract 14

`font`, needs to be a global variable as it is needed in the Preload function and setup, however the Points class remains encapsulated as font is one of the parameters required to create a new object.
Three arrays necessary for game play, `sudokuValues` keeps the integer values for the grid displayed on the screen, `displaySudoku`is an array of objects of the Points class which hold the screen attributes of the corresponding integers in `sudokuValues`. `actualSudoku` is an array of the actual values which the completed table should have if the grid has been completed properly. `completeText` is the text which will be displayed to the user when the grid has been complete and `completedArr` will store the character representation in class `Points ` for the characters in `completeText`. `completeIndi` is the boolean variable which indicates if the grid has been completed, as opposed to calling the function `isComplete`, whenever it is costs too much Processing time to decide if the grid is complete.

## Preload function

``` javascript
function preload() {
       font = loadFont('AvenirNextLTPro-Demi.otf');
   }
```
Code Extract 15

This function is responsible for loading the desired font `AvenirNextLTPro-Demi` otf file.

## sudokuTable Function

This function will take the already made sudoku table and generates a valid permutation of the grid which is still solvable. This would take less time then generating a whole sudoku grid with a backtracking algorithm, however this is more of a proof of concept. There are till 3! * 3! different ways of generating this grid, and there are 53 elements removed from the grid, the remaining 28 elements are not updatable by the user.

``` javascript

function sudokuTable(){

    // shuffles vertical sets
    let shift1 = int(random(3))
    let shift2 = int(random(3))
    let shift3 = int(random(3))
    while (shift2 == shift1){
      shift2 = int(random(2))
    }
    while ((shift3 == shift1)||(shift3 == shift2)){
      shift3 = int(random(2))
    }
    shift1 = actualSudoku.slice((shift1*27),(shift1*27) + 27);
    shift2 = actualSudoku.slice((shift2*27),(shift2*27) + 27);
    shift3 = actualSudoku.slice((shift3*27),(shift3*27) + 27);
    actualSudoku = []
    actualSudoku = actualSudoku.concat(shift1,shift2,shift3);

```
Code Extract 16.1

  Three different random numbers will be generated 0,1,2. The code will then take the first second, and third 27 elements from actual sudoku shuffle them into a random order with a potential 3! permutations. And then concatenate them into `actualSudoku` once again.


``` javascript

    // shuffles horizontal sets

    shift1 = int(random(3))
    shift2 = int(random(3))
    shift3 = int(random(3))
    while (shift2 == shift1){
      shift2 = int(random(2))
    }
    while ((shift3 == shift1)||(shift3 == shift2)){
      shift3 = int(random(2))
    }

    let shift_temp =shift1;
    shift1 = [];
    for (var x = shift_temp*3; x < ((shift_temp*3)+81); x+= 9)
         shift1 = shift1.concat(actualSudoku.slice(x,(x+3)));
    shift_temp = shift2;
    shift2 = [];
    for (var x = shift_temp*3; x < ((shift_temp*3)+81); x+= 9)
        shift2 = shift2.concat(actualSudoku.slice(x,(x+3)));
    shift_temp = shift3;
    shift3 = [];
    for (var x = shift_temp*3; x < ((shift_temp*3)+81); x+= 9)
        shift3 = shift3.concat(actualSudoku.slice(x,(x+3)));
```
Code Extract 16.2

  Three different random numbers will be generated 0,1,2. The code will then take the rightmost 27 elements, the middle 27 elements and the left most 27 elements, shuffle them into a random order with a potential 3! permutations.

``` javascript
    // paste them all together
    actualSudoku = [];
    for (var i = 0; i < 81; i+= 3) {
     actualSudoku = actualSudoku.concat(shift1.slice(i,(i+3)))
     actualSudoku = actualSudoku.concat(shift2.slice(i,(i+3)))
     actualSudoku = actualSudoku.concat(shift3.slice(i,(i+3)))
    }
```
Code Extract 16.3

This code will then concatenate the 3 shuffled 27 element arrays, and then concatenate them back into the `actualSudoku` array .

``` javascript
    // equate actual sudoku to sudoku values
     for (var i = 0; i < actualSudoku.length; i++) {
       sudokuValues[i] = actualSudoku[i]
     }
```
Code Extract 16.4

This code will then equate `actualSudoku` to `sudokuValues`, to keep them synchronised before having some elements removed from `sudokuValues` in order to make the game playable.

``` javascript
     // remove 53 elements from sudoku values.
  for (var i = 0; i < 53; i++) {
    let x = int(random(81))
    if (sudokuValues[x] != 0){
    sudokuValues[x] = 0;
  }else{ i--}
  }
}
```
Code Extract 16.5

This will then take `sudokuValues`, generate a random index between 0 and 81. The value in this inex is set to 0, 0 is not displayed to the player, and thus is equivalent to null.

## checkIfcomplete Funtion

``` javascript
function checkIfcomplete(){
  if (!completeIndi){
  for (var i = 0; i < actualSudoku.length; i++) {
    if (actualSudoku[i] != sudokuValues){
      completeIndi = false;
      return false;
    }
  }
  if(!completeIndi){
    completeIndi = true;
    return true;
  }
}
}
```
Code Extract 17

This function comparees every element in `actualSudoku` to `sudokuValues`. If there are any elements which are not equal then the function doesn't continue to compare and simply returns false, if the comparisons equate the iteration terminates and therefore it can be assumed that no non-equalities and therefore the grid is complete. `completeIndi` is set to true and the function returns true.

## decideColours Function

``` javascript
function decideColours(i){
  let z  = map(displaySudoku[i].RepresentedVal,0,9,0,225)
  let temp = [z*2,map(z,0,250,100,120),z*0.75]
  displaySudoku[i].updateColour(temp);
}
```
Code Extract 18

This function will take an argument which is index of displaySudoku object for which the `RepresentedVal` is taken, this is mapped to a value between 0 and 225, this value will then be taken and an RGB value is generated in list form to calculate a color for each of 0-9 which is unique. This is to demonstrate that each objects is reusable and to make game play easier as the user can see pattern more easily.

## showGrid Function
``` javascript
function showGrid(){


  for (var x = 0; x < 10; x++) {
    let red = 250;
    let green = 0;
    if (x == 0 || x == 3 || x == 6 || x == 9){
      green = 250;
      red = 0;
    }
    for (var i = 15; i < 920; i+= 10) {
      strokeWeight(4);
      stroke(red,green,0);
      point((90 + 99*x),i);
    }
  }
  for (var x = 0; x < 10; x++ ) {
    let red = 250;
    let green = 0;
    if (x == 0 || x == 3 || x == 6 || x == 9){
      green = 250;
      red = 0;
    }
    for (var i = 90; i < 980; i+= 10) {
      strokeWeight(4);
      stroke(red,green,0)
      point(i,(15 + 100*x));
    }
  }

}
```
Code Extract 19

This function will display a grid on the screen which is just a collection of points separate by 10 - 4 = 6 pixels, they are green to border squares of size 9 and red to border the green sub-squares.

## mousePressed Function
``` javascript
function mousePressed(){

  for (var iii = 0; iii < sudokuValues.length; iii++) {
    if (((mouseX > displaySudoku[iii].locX) && (mouseX < displaySudoku[iii].locX + 60)) && (!displaySudoku[[iii]].cannotBeUpdated) &&
        ((mouseY < displaySudoku[iii].locY +10 )&& (mouseY > displaySudoku[iii].locY -90))) {
          sudokuValues[iii] = (sudokuValues[iii] % 9) + 1
          displaySudoku[iii].RepresentedVal = sudokuValues[iii].toString();
          decideColours(iii);
          displaySudoku[iii].updateText(displaySudoku[iii].RepresentedVal);
    }
  }
  checkIfcomplete()
}
```
Code Extract 20

This function is a global function call from the p5js library whenever a mouse click is registered on the browser. The code then uses the `mouseX` and `mouseY` variables to assess which object has been clicked on. A loop which assesses which (if at all) object's bounds  the mouse location is within. THe bounds are established manually through testing that for the font size 192, the bounds are within 60 pixels of the `displaySudoku[iii].locX` and within 80 pixels of `displaySudoku[iii].locY`.

When the object is found It is tested to see if this object can be updated and if so, the represented value is incremented and the `sudokuValues` corresponding value is also incremented between 0-9. A colour for the new `RepresentedVal` is created and the `updateText` function is called with the new `RepresentedVal`. This is now a good opportunity to check if the grid has been complete, as it is too processor expensive to put this test in the draw function.

## setup Function
``` javascript
function setup(){

createCanvas(1100,1000);
background(51);

let xcount = 100;
let ycount = 100;
let updatability = false;
let weight = 6;

 sudokuTable();
 for (var i = 0; i < 81; i++) {

   if (sudokuValues[i] == 0) {
     updatability = false;
     weight = 6;
   }else{
     updatability = true;
     weight = 8;
   }

  let xx = new Points(sudokuValues[i].toString(),xcount,ycount,font,100,weight,updatability,[250,250,250],20);
  displaySudoku.push(xx);
  decideColours(i);
  displaySudoku[i].updateText(sudokuValues[i].toString());
  xcount = xcount + 100;

  if (( ((i+1) % 9) == 0) && (i != 0) && (i != 79) || (i == 8)){
  xcount = 100;
  ycount = ycount + 100;
     }

  }

```
Code Extract 21.1

This Code starts with creating a canvas, and setting its background, the starting position for the first element is (100,100). sudokuTable is called to generate a new `sudokuValues` grid with 53 items eliminated. a loop is started which creates new objects of lass points with weight 8 for fixed unupdatable items and the `updatability` argument set to false for values `!= 0`. the colours of the elements added are decided and `updateText` is called to start drawing the values on the sudoku grid. xcount is incremented by 100 to give a spacing of 100 pixels between the objects on the grid. ycount is incremented if there are 9 objects in the row already. `10` is the parameter handed that indicates the particles' time to arrive.

``` javascript

  xcount = 100;
  ycount = 500;
  updatability = true;
  weight = 6;


    for (var i = 0; i < completeText.length; i++) {


      xx = new Points(completeText[i],xcount,ycount,font,200,weight,updatability,[250,0,0],20);
      completedArr.push(xx)
      completedArr[i].updateText(completedArr[i]);
      xcount += 100
    }

  showGrid()
}
```
Code Extract 21.2

This part of the function is here to serve the same purpose as above only for the message displayed when the grid has been complete and with an RGB value of `(250,0,0)`. and the game is over.
The showGrid function is called to display the grid to the user.

## draw Function

``` javascript
function draw(){

 if (!completeIndi){
  background(51);
  showGrid()

 for (var ii = 0; ii < sudokuValues.length; ii++) {

    if (sudokuValues[ii] != 0){
     displaySudoku[ii].display();
    }
  }
} else {

    background(51);
    for (var ii = 0; ii < completedArr.length; ii++) {
        completedArr[ii].display();

      }
   }
}
```
Code Extract 22

The Function starts by checking which state the game is in, either complete or not. If it is incomplete, the background and grid are refreshed. all the objects in the `displaySudoku` array that do not have a `RepresentedVal = 0` are displayed on the screen. Otherwise the Background is refreshed and the points objects in the `completedArr` are drawn on the Canvas only.


# The ProofOfConcept sketch
## This file is meant to demonstrate the reusability of my code.
It consists of a set of sliders, check boxes and dropdown lists to modify a single object of the exact classes above, (class Points, and thus its subclass Vehicles).

``` javascript
function preload() {
  font0 = loadFont('Fonts/AvenirNextLTPro-Demi.otf');
  font1 = loadFont('Fonts/Comfortaa-Bold.ttf');
  font2 =loadFont(`Fonts/Exo-ExtraBold.otf`)
}
```
Code Extract 23
Here I load 3 different fonts for the user to interact with.


``` javascript
function setup(){
    canvaas = createCanvas(400,550)
    canvaas.position(520,150)

```
Code Extract 24.1

This creates a canvas and stores it in a variable `canvaas`, This allows for relocation of the canvas without resorting to CSS, This makes adding DOM and changing their locations more easy.

``` javascript

    repval = String.fromCharCode(34)

```
Code Extract 24.2

This converts the ascii value in `repval` to the character to be presented on the screen.
``` javascript

    aPoint = new Points(repval,locX,locY,font0,fontSize,weight,updatability,[reD,greeN,bluE],maximumVel);
    aPoint.updateColour([reD,greeN,bluE])
    aPoint.updateText(repval)

```
Code Extract 24.3

This code will create the Points object with all the modifiable attributes for which inputs will be created, The only exception is the `locX` and `locY` variables, as this has already been demonstrated on the `Sudoku.js` sketch.

``` javascript

    let group = createDiv('');
    group.position(100, 150);
    reD = createSlider(0,250,0);
    reD.style('background', 'red');
    reD.parent(group);
    let label1 = createSpan('  Red');
    label1.parent(group);

    group = createDiv('');
    group.position(100, 250);
    greeN = createSlider(0,250,0);
    greeN.style('background', 'Green');
    greeN.parent(group);
    label1 = createSpan('  Green');
    label1.parent(group);

    group = createDiv('');
    group.position(100, 350);
    bluE = createSlider(0,250,0);
    bluE.style('background', 'Blue');
    bluE.parent(group);
    label1 = createSpan('  Blue');
    label1.parent(group);

    group = createDiv('');
    group.position(100, 450);
    repval2 = createSlider(34,126,34);
    repval2.parent(group);
    label1 = createSpan('  Character');
    label1.parent(group);

    group = createDiv('');
    group.position(150, 525);
    fontSize2 = createSlider(50,500,440);
    fontSize2.parent(group);
    label1 = createSpan('  Font Size');
    label1.parent(group);

    checkbox = createCheckbox('Lock');
    checkbox.checked(false);
    checkbox.position(300,150);

    group = createDiv('');
    group.position(300,250);
    dropdown = createSelect(); // or create dropdown?
    dropdown.option('Avenir');
    dropdown.option('Comfortaa');
    dropdown.option('Exo');
    dropdown.changed(changeFont);
    dropdown.parent(group);
    label1 = createSpan('  Font')
    label1.parent(group);

    group = createDiv('');
    group.position(300, 350);
    weight2 = createSlider(2,20,6);
    weight2.parent(group);
    label1 = createSpan("  Radius");
    label1.parent(group);

    group = createDiv('');
    group.position(300, 450);
    maximumVel2 = createSlider(5,3,10);
    maximumVel2.parent(group);
    label1 = createSpan("  Max Speed")
    label1.parent(group);
}
```
Code Extract 24.4.0

This code creates 7 sliders, a dropdown menu and a check box. `group = createDiv('');` will create a div in the HTML document; `group.position(x?, y?);` wi move the div to a desired location on the HTML document. `global variable = createSlider(minimum,maximum,starting position);` will create a slider and assign its attributed value to the global variable. `global variable.parent(group);` will then attach the slider to the div created, thus keeping it inline with the previously defined location. `    label1 = createSpan("  Max Speed"); label1.parent(group);` will create a label with a desired message and attach it to the slider. This is repeated for all the slideers only varying the attached variable and their locations.

The slider `reD` maps the red RGB value of the object between 0 and 250. `bluE` does the same for the RGB value of blue,`greeN` repeats the same for green. `weight2` is a slider that maps the `strokeWeight` of the points displayed on the canvas, between 2 and 20. `maximumVel2` is the speed corresponding to the attribute `maxspeed` in the vehicles object which with the steering force algorithms change how quickly the vehicles arrive at their target.
`repval` will hold an ascii value which will later be converted to the `RepresentedVal` of aPoints. `checkbox` will dictate whether aPoints is updatable.

``` javascript
checkbox = createCheckbox('Lock');
checkbox.checked(false);
checkbox.position(300,150);
```
Code Extract 24.4.1

This code will create a check box at the `300,150` coordinate. with the message `Lock` and initialise the checkbox to false

``` javascript
group = createDiv('');
group.position(300,250);
dropdown = createSelect(); // or create dropdown?
dropdown.option('Avenir');
dropdown.option('Comfortaa');
dropdown.option('Exo');
dropdown.changed(changeFont);
dropdown.parent(group);
label1 = createSpan('  Font')
label1.parent(group);
```
Code Extract 24.4.2

This section will take create a dropdown menu with 3 options for the three fonts, A global function call is made whenever an item on the menu is changed the function `changeFont` is called. The same process of attaching a label and the menu to a div is explained further in Code Extract 24.4.0


``` javascript
function changeFont(){
  let fontCounter = this.selected()

  if (fontCounter == 'Avenir') {
    aPoint.font = font0;
    aPoint.updateText(repval);
  } else if (fontCounter == 'Comfortaa') {
    aPoint.font = font1;
    aPoint.updateText(repval);
  } else if (fontCounter == 'Exo') {
    aPoint.font = font2;
    aPoint.updateText(repval);
  }

}
```
Code Extract 25

This is a function called whenever the item in the dropdown menu has been changed. the `this.selected()` function is equivalent to `this.value()` and will return the item defined in the menu. In this case it is simply a string with the name of the font. Once `aPoint.font` is updated with the corresponding font on the menu `aPoint.updateText()` is called on the represented value: `repval`.

``` javascript

function draw(){

  background(51);
  aPoint.display();
  aPoint.updateColour([reD.value(),greeN.value(),bluE.value()])

  if (String.fromCharCode(repval2.value()) != repval){
    repval = String.fromCharCode(repval2.value())
    aPoint.RepresentedVal = repval
    aPoint.updateText(aPoint.RepresentedVal)
  }
  if (checkbox.checked()) {
    aPoint.cannotBeUpdated = true;
  } else{
    aPoint.cannotBeUpdated = false;
    repval = String.fromCharCode(repval2.value())
    aPoint.RepresentedVal = repval;
    aPoint.updateText(aPoint.RepresentedVal);
  }

  if ((weight2.value() != weight)||(maximumVel != maximumVel2.value())||(fontSize2.value() != fontSize)){
    weight = weight2.value()
    maximumVel = maximumVel2.value()
    fontSize = fontSize2.value()
    let aPoint_ = new Points(repval,locX,locY,aPoint.font,fontSize,weight,updatability,[reD.value(),greeN.value(),bluE.value()],maximumVel);
    aPoint = aPoint_
    aPoint.updateText(repval)
  }
}
```
Code Extract 26

The Draw functions inherent infinite loop is made use of, by displaying the object `aPoints`, updating the colour for every iteration. and series of tests are made to check if any of the sliders or check boxes is made. If the ascii value represented by `repval2` slider is different to the character held in `repval` the `representedvalue` is updated and the sketch is refreshed.

If the `checkbox` has been updated then the object is locked otherwise `aPoints` is updated with any changes made in the interim. If any of the three remaining sliders is updated a object needs to be created, as it would be quicker to do so than to go through every vehicle attributed to `Vehicles` to update their attributes. While it would be a simple for loop.

The HTML files are relatively straightforward,

## SudokuPlayer.HTML

``` HTML
<!DOCTYPE html>
<html>
    <head><title> Sudoku Player </title>
      <link rel="stylesheet" type="text/css" href="stylesheet.css">
    </head>
    <style>
    body {background-color: #333333;
      }</style>
    <body>
      <div class="content">
      <hd> <b>VQWH89 Sudoku </b>, click on any square to increment it's value!</hd>
    </div>
    <script src="Sudoku.js"></script>
    <script src="p5/p5.js"></script>
    </body>
</html>


```
I use locally stored p5.js libraries to reduce the time taken for the script to load as opposed to a content delivery network. the `#333333` background is to match the `background(51)` of the canvas.

## ObjectIllustration.HTML

``` HTML

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1"> <title> Sliders </title>
<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
<div class="content">
<h1> <b>VQWH89</b> Each character is an instance of Points Class and each individual point on the canvas is an instance of the Vehicles Class.</h1>
<h1><b>Modifiable Characteristics:</b></h1>
<div id="sketch-holder">
</div>
<div class="slidecontainer">
  <h2><b>Lock:</b></h2>
  <input type="range" min="1" max="2" value="1" class="slider" id="LOCK">
</div>
<div class="slidecontainer">
  <h2><b>Red RGB:</b></h2>
  <input type="range" min="0" max="250" value="250" class="slider" id="RED">
</div>
<div class="slidecontainer">
  <h2><b>Green RGB:</b></h2>
  <input type="range" min="0" max="250" value="250" class="slider" id="GREEN">
</div>
<div class="slidecontainer">
  <h2><b>Blue RGB:</b></h2>
  <input type="range" min="0" max="250" value="250" class="slider" id="BLUE">
</div>
<div class="slidecontainer">
  <h2><b>Dot Radius:</b></h2>
  <input type="range" min="2" max="15" value="6" class="slider" id="RADIUS">
</div>
<div class="slidecontainer">
  <h2><b>Particle Maximum Speed:</b></h2>
  <input type="range" min="5" max="30" value="10" class="slider" id="MAXSPEED">
</div>
<div class="slidecontainer">
  <h2><b>ASCII Character:</b></h2>
  <input type="range" min="34" max="126" value="34" class="slider" id="ASCII">
</div>
<div class="slidecontainer">
  <h2><b>Font Size:</b></h2>
  <input type="range" min="50" max="500" value="440" class="slider" id="FONTSIZE">
</div>
<div class="slidecontainer">
  <h2><b>Font:</b></h2>
  <input type="range" min="1" max="3" value="1" class="slider" id="FONT">
</div>

<script src="p5/p5.js"></script>
<script src="sliders.js"></script>

</div>
</body>
</html>

```

I use 9 Sliders in HTML, to control the visible characteristics of the class, Properties of the sliders can be seen in the stylesheet.


``` CSS
@font-face {
  font-family: "myFirstFont";
  src: url("Fonts/AvenirNextLTPro-Demi.otf") format("opentype"),
}
.AvenirNextLTPro{
  font-family:"myFirstFont";
}

h1 {
font-family: 'myFirstFont', Arial, sans-serif;
font-weight:normal;
font-style:normal;

}

hd {
  font-family: 'myFirstFont', Arial, sans-serif;
  font-weight:normal;
  font-style:normal;
  font-size: 50px;
  color: #ffffff;
}

h2 {
font-family: 'myFirstFont', Arial, sans-serif;
font-weight:normal;
font-style:normal;
}
.slider {
  -webkit-appearance: none;
  width: 75%;
  height: 15px;
  border-radius: 5px;
  background: #333333;
  outline: none;
  opacity: 0.7;
  -webkit-transition: .2s;
  transition: opacity .2s;
}

.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 25px;
  height: 25px;
  border-radius: 50%;
  background: #FF3232;
  cursor: pointer;
}

.slider::-moz-range-thumb {
  width: 25px;
  height: 25px;
  border-radius: 50%;
  background: #FF3232;
  cursor: pointer;
}
.content {
max-width: 1000px;
margin: auto;
}

```

The slider is given different appearances for different browsers to ensure a unified view of the sliders cross platform. code and advice has to how these were made are available here `https://www.w3schools.com/howto/howto_js_rangeslider.asp`. class `hd` is dedicated for `SudokuPlayer.html` and `h1` is used for `Sliders.html`
