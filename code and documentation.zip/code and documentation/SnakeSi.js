class SnakeSi{
	constructor(){
		this.padding = 30;
		this.border = 50;
		
		this.cellsize = 10;
		this.gridsize = 10;
		this.size = 0;
		this.count = 5;
		this.snakes = [];
		this.cob=0;
		this.rSlider = createSlider(0, 255, 100);
    	this.rSlider.position(20, 20);
  }
		
	
	draw(){
		this.size = this.gridsize * this.cellsize;

	

	createCanvas((this.size * this.count) + ((this.count - 1) * this.padding) + this.border * 2, (this.size * this.count) + ((this.count - 1) * this.padding) + this.border * 2);

	noFill();
	strokeWeight(this.cellsize / 2);
	strokeCap(ROUND);
	frameRate(15);

	for (var y = 0; y < this.count; y++)
		for (var x = 0; x < this.count; x++)
			for (var i = 0; i < 3; i++)
				this.snakes.push(new Snake(x * this.size + x * this.padding + this.border, y * this.size + y * this.padding + this.border));
	}
	draw2(){
		
		noStroke();
fill(0,0,20+this.rSlider.value(),50);
	rect(0,0,width,height,30);

	for (var i = 0; i < snakes.length; i++) {
		snakes[i].update();
		snakes[i].draw();
		if (snakes[i].dead) snakes[i] = new Snake(snakes[i].x, snakes[i].y);
	}
	}
	drawSetup(){
		
	init();
	}
	setbackground(cob){
		this.cob=cob;
	}
	getbackground(){
		return this.cob;
	}
	
	
	
	
	
	
}
var cellsize = 10;
var gridsize = 10;
var size = 0;
var count = 5;
var snakes = [];
function init() {	
size = gridsize * cellsize;

	var padding = 30;
	var border = 50;

	createCanvas((size * count) + ((count - 1) * padding) + border * 2, (size * count) + ((count - 1) * padding) + border * 2);

	noFill();
	strokeWeight(cellsize / 2);
	strokeCap(ROUND);
	frameRate(15);

	for (var y = 0; y < count; y++)
		for (var x = 0; x < count; x++)
			for (var i = 0; i < 3; i++)
				snakes.push(new Snake(x * size + x * padding + border, y * size + y * padding + border));
}