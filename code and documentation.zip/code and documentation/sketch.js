var sk;
var ske;
function setup() {
	sk=new SnakeSi();
	sk.setbackground(0);
  background(sk.getbackground());
  colorMode(HSB,360,100,100,100);  	
  ske=new Snake();
  sk.drawSetup();
}
function draw() {
sk.draw2();
}

