# Twisted Lines animation documentation 
## Description ## 
The animation in p5 will generate multiple distorted lines and the color will change. This program adjusts the background color to have a black and white background color.

## Requirements ##
p5
ESCRIPT 2015(ES6)
---
I seperated my code into three parts: **snake.js**, **snakesi.js**,**sketch.js** and **index.html**
## Usage (Divided by parts)
## Part 1
The first part is snake.js.It including the variable which use to use the class and draw function.
The following is my code
```javascript
class Snake{
	constructor(x, y){
this.dead = false;
	this.x = x;
	this.y = y;
	
	this.segCount = random(2, 10);
	this.segs = [];

	this.dir = p5.Vector.fromAngle(floor(random(4)) * (TWO_PI / 4)).mult(cellsize);

	//var size = gridsize*cellsize;

	this.pos = createVector(Math.ceil(random(size) / cellsize) * cellsize, Math.ceil(random(size) / cellsize) * cellsize);

	this.newPos = createVector(0, 0);

	this.frames = 0;

	this.segs.push(this.pos);
	this.rot=0;
	this.s;
	this.e;
	this.c = color(random(360), random(10, 70), 100);
  }
	update(){
				if (random() < 0.3) {
			this.frames = 0;
			
			while (this.rot == 0) {
				this.rot = round(random(-1, 1));
			}
			this.dir.rotate(TWO_PI / 4 * this.rot);
		}

		//move
		this.newPos = p5.Vector.add(this.pos, this.dir);

		this.segs.unshift(this.newPos);
		this.pos = this.newPos;

		if (this.segs.length > this.segCount) this.segs.pop();
		
	}
		
	
	draw(){
		stroke(this.c);
		this.dead = true;

		for (var i = 0; i < this.segs.length - 1; i++) {
			this.s = this.segs[i];
			this.e = this.segs[i + 1];

			if (this.s.x >= 0 && this.s.x <= size && this.s.y >= 0 && this.s.y <= size) {
				if (this.e.x >= 0 && this.e.x <= size && this.e.y >= 0 && this.e.y <= size) {

					line(this.s.x + this.x, this.s.y + this.y, this.e.x + this.x, this.e.y + this.y);
					line(this.s.y + this.x, this.s.x + this.y, this.e.y + this.x, this.e.x + this.y);

					line(size - this.s.x + this.x, this.s.y + this.y, size - this.e.x + this.x, this.e.y + this.y);
					line(size - this.s.y + this.x, this.s.x + this.y, size - this.e.y + this.x, this.e.x + this.y);

					line(this.s.x + this.x, size - this.s.y + this.y, this.e.x + this.x, size - this.e.y + this.y);
					line(this.s.y + this.x, size - this.s.x + this.y, this.e.y + this.x, size - this.e.x + this.y);

					line(size - this.s.x + this.x, size - this.s.y + this.y, size - this.e.x + this.x, size - this.e.y + this.y);
					line(size - this.s.y + this.x, size - this.s.x + this.y, size - this.e.y + this.x, size - this.e.x + this.y);

					//dead check

					this.dead = false;
				}
			}
		}

		frames++;

		stroke(0, 0, 75);
    noFill();
		rect(this.x, this.y, size, size, 5, 5, 5, 5);
	}
	
	
	
	
	
}
```
## Part 2
The **snakesi.js** is the second part of my code, it including the setup and draw, mousepressed function.
```javascript
let l;

function setup(){
    l = new lines();
}

function draw(){
    l.draw();
}
function mousePressed(){
	l.mousePressed();
}
```
## Part 3
The sketch.js is the third part of my code, in this part, it includes the variables.
```javascript
var sk;
var ske;
function setup() {
	sk=new SnakeSi();
	sk.setbackground(0);
  background(sk.getbackground());
  colorMode(HSB,360,100,100,100);  	
  ske=new Snake();
  sk.drawSetup();
}
function draw() {
sk.draw2();
}


```
## Part 3
The index.html is the third part of my code, in this part, I created a html file in order to use p5 run my javascript code.
```html
<!DOCTYPE html>
<html>
  <head>
   
    <script src="libraries/p5.js" ></script>

    <script src="libraries/p5.dom.js" ></script>
    <script src="libraries/p5.sound.js" ></script>

    <script src="sketch.js" ></script>
    <script src="Snake.js" ></script>
    <script src="SnakeSi.js" ></script>
    


    <style> body {padding: 0; margin: 0;}  </style>
  </head>
  <body>
  </body>
</html>
```


































