class Snake{
	constructor(x, y){
this.dead = false;
	this.x = x;
	this.y = y;
	
	this.segCount = random(2, 10);
	this.segs = [];

	this.dir = p5.Vector.fromAngle(floor(random(4)) * (TWO_PI / 4)).mult(cellsize);

	//var size = gridsize*cellsize;

	this.pos = createVector(Math.ceil(random(size) / cellsize) * cellsize, Math.ceil(random(size) / cellsize) * cellsize);

	this.newPos = createVector(0, 0);

	this.frames = 0;

	this.segs.push(this.pos);
	this.rot=0;
	this.s;
	this.e;
	this.c = color(random(360), random(10, 70), 100);
  }
	update(){
				if (random() < 0.3) {
			this.frames = 0;
			
			while (this.rot == 0) {
				this.rot = round(random(-1, 1));
			}
			this.dir.rotate(TWO_PI / 4 * this.rot);
		}

		//move
		this.newPos = p5.Vector.add(this.pos, this.dir);

		this.segs.unshift(this.newPos);
		this.pos = this.newPos;

		if (this.segs.length > this.segCount) this.segs.pop();
		
	}
		
	
	draw(){
		stroke(this.c);
		this.dead = true;

		for (var i = 0; i < this.segs.length - 1; i++) {
			this.s = this.segs[i];
			this.e = this.segs[i + 1];

			if (this.s.x >= 0 && this.s.x <= size && this.s.y >= 0 && this.s.y <= size) {
				if (this.e.x >= 0 && this.e.x <= size && this.e.y >= 0 && this.e.y <= size) {

					line(this.s.x + this.x, this.s.y + this.y, this.e.x + this.x, this.e.y + this.y);
					line(this.s.y + this.x, this.s.x + this.y, this.e.y + this.x, this.e.x + this.y);

					line(size - this.s.x + this.x, this.s.y + this.y, size - this.e.x + this.x, this.e.y + this.y);
					line(size - this.s.y + this.x, this.s.x + this.y, size - this.e.y + this.x, this.e.x + this.y);

					line(this.s.x + this.x, size - this.s.y + this.y, this.e.x + this.x, size - this.e.y + this.y);
					line(this.s.y + this.x, size - this.s.x + this.y, this.e.y + this.x, size - this.e.x + this.y);

					line(size - this.s.x + this.x, size - this.s.y + this.y, size - this.e.x + this.x, size - this.e.y + this.y);
					line(size - this.s.y + this.x, size - this.s.x + this.y, size - this.e.y + this.x, size - this.e.x + this.y);

					//dead check

					this.dead = false;
				}
			}
		}

		frames++;

		stroke(0, 0, 75);
    noFill();
		rect(this.x, this.y, size, size, 5, 5, 5, 5);
	}
	
	
	
	
	
}
