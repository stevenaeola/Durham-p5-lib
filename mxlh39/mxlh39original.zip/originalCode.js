const meteoCount = 1;
const maxMeteos = 128;
let meteos = new Array(meteoCount);
let me;
let startTime;
let nowMinStr, nowSecStr, nowMilSecStr;
let tmpLvupTime = 0, lvupTime = false;
let fo = 200;
let stageAlpha = .2;
let crashSE,myFont;

function preload() {
	crashSE = loadSound('crash.mp3');
	myFont = loadFont('Anton-Regular.ttf');
}

function setup() {
	createCanvas(600, 600);
	textFont(myFont);
	colorMode(HSB);
	background(0);
	for (var i = 0; i < meteos.length; i++) {
		meteos[i] = new Meteo(random(width), random(height));
	}
	me = new Me();
	startTime = Date.now();
}

function draw() {
	fill(0, 0, 0, stageAlpha);
	stroke(0,100,50,1)
	rect(0, 0, width, height);
	if (me.isAlive) {
		for (let i = 0; i < meteos.length; i++) {
			meteos[i].update();
			meteos[i].checkEdges();
			meteos[i].disp(225, 22, 100);
		}
		me.checkEdges();
		me.disp(0, 50, 100);
		checkLocs();
		getTime();
		if (lvupTime) { lvup(); }
	}

	if (!me.isAlive) {
		if (fo >= 0) {
			for (let i = 0; i < meteos.length; i++) {
				for (let rotAngle = 0; rotAngle < 360; rotAngle += 45) {
					push();
					translate(meteos[i].loc.x, meteos[i].loc.y);
					rotate(radians(rotAngle));
					noStroke();
					fill(random(180, 300), 100, 100, fo / 100);
					ellipse(0, 105 - fo / 2, meteos[i].rad * map(fo, 200, 0, 10, 1));
					pop();
				}
			}
			fo -= 2;
		}
		me.disp(240, 40, 40);
		if (fo < 0) {
			noStroke();
			fill(0, 0, 100, 1);
			textSize(70);
			text('GAME OVER', 150, height / 2 - 90);
			text(nowMinStr, 175, height / 2 + 40);
			text(':' + nowSecStr, 250, height / 2 + 40);
			text(':' + nowMilSecStr, 340, height / 2 + 40);
			textSize(30);
			text('RELOAD TO TRY AGAIN', 182, height / 2 + 140);
			noLoop();
		}
	}
}

function checkLocs() {
	for (var i = 0; i < meteos.length; i++) {
		if (dist(me.loc.x, me.loc.y, meteos[i].loc.x, meteos[i].loc.y) < me.rad / 4) {
			stageAlpha = 1;
			me.isAlive = false;
			crashSE.play();
		}
	}
}

function lvup() {
	let nowLength = meteos.length;
	for (let i = 0; i < nowLength; i++) {
		meteos.push(new Meteo(meteos[i].loc.x, meteos[i].loc.y))
	}
	lvupTime = false;
}

class Meteo {
	constructor(ex, why) {
		this.accel;
		this.loc = createVector(ex, why);
		this.vel = createVector(0, 0);
		this.rad = 8;
		this.topsp = 3.8;
	}

	update() {
		var mouse = createVector(mouseX, mouseY);
		var dir = p5.Vector.sub(mouse, this.loc);
		var magn = p5.Vector.mag(dir);
		dir.normalize();
		dir.mult(10 / magn);
		this.accel = dir;
		this.vel.add(this.accel);
		this.vel.limit(this.topsp);
		this.loc.add(this.vel);
	}

	disp(h, s, b) {
		noStroke();
		fill(h, s, b, 1);
		ellipse(this.loc.x, this.loc.y, this.rad);
	}

	checkEdges() {
		if (this.loc.x > width) {
			this.loc.x = 0;
		} else if (this.loc.x < 0) {
			this.loc.x = width;
		}
		if (this.loc.y > height) {
			this.loc.y = 0;
		} else if (this.loc.y < 0) {
			this.loc.y = height;
		}
	}
}

class Me {
	constructor() {
		this.loc = createVector(0, 0);
		this.rad = 15;
		this.isAlive = true;
	}
	checkEdges() {
		var mX = mouseX, mY = mouseY;
		if (mX > width) {
			mX = width;
		} else if (mX < 0) {
			mX = 0;
		}
		if (mY > height) {
			mY = height;
		} else if (mY < 0) {
			mY = 0;
		}
		this.loc = createVector(mX, mY);
	}
	disp(h, s, b) {
		noStroke();
		fill(h, s, b, 1);
		ellipse(me.loc.x, me.loc.y, this.rad);
		noFill();
		stroke(h, s, b, 1);
		strokeWeight(2);
		ellipse(me.loc.x, me.loc.y, this.rad + 7);
	}
}

function getTime() {
	let justnow = Date.now() - startTime;
	let nowMin = floor(justnow / 1000 / 60);
	let nowSec = floor(justnow / 1000 % 60);
	let nowMilSec = floor((justnow - nowMin * 60000 - nowSec * 1000) / 10);
	nowMinStr = setzero(nowMin);
	nowSecStr = setzero(nowSec);
	nowMilSecStr = setzero(nowMilSec);
	if (nowSec % 10 == 0 && nowSec != tmpLvupTime) {
		if (meteos.length < maxMeteos) { lvupTime = true; }
		tmpLvupTime = nowSec;
	}

	noStroke();
	fill(0, 0, 100, .02);
	textSize(70);
	text(nowMinStr, 175, height / 2 + 40);
	text(':' + nowSecStr, 250, height / 2 + 40);
	text(':' + nowMilSecStr, 340, height / 2 + 40);
}

function setzero(num) {
	let addzero;
	if (num < 10) {
		addzero = "0" + num;
	} else { addzero = num; }
	return addzero;
}