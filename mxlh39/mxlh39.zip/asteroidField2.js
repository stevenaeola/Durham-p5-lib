//Based on "Meteoroids" by Katsumi Shibata
//http://www.openprocessing.org/sketch/537362
//Licensed under Creative Commons Attribution ShareAlike
//https://creativecommons.org/licenses/by-sa/3.0
//https://creativecommons.org/licenses/GPL/2.0/

let asteroidField;


function setup() {			//main P5 setup function - creates the canvas, sliders, etc
	asteroidField = new AsteroidField(1, 6);
	var c = createCanvas(800, 800);
	asteroidField.setup(c);
}

function draw() {		//main P5 draw function - called every frame
	asteroidField.draw();
}

function mouseClicked(){		//when mouse is clicked, if it is on the canvas, it generates a new asteroid and sticks it into the asteroid array
	if ((asteroidField.cursor.isOnScreen()) && (asteroidField.asteroids.length < asteroidField.maxAsteroids)) {
		asteroidField.asteroids.push(new Asteroid(random(width),random(height)));
	}
}
