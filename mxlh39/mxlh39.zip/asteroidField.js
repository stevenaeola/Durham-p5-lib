//Based on "Meteoroids" by Katsumi Shibata
//http://www.openprocessing.org/sketch/537362
//Licensed under Creative Commons Attribution ShareAlike
//https://creativecommons.org/licenses/by-sa/3.0
//https://creativecommons.org/licenses/GPL/2.0/

class AsteroidField {		//main class of the program, mostly performs interactions with the other classes
	constructor(asteroidCount = 1, maxAsteroids = 64){
		this.asteroidCount = asteroidCount;		//the number of asteroids currently active
		this.maxAsteroids = maxAsteroids;		//the maximum number of asteroids allowed to be active
		this.asteroids = new Array(asteroidCount);		//array holding all active asteroids
		this.cursor;		//mouse cursor object
		this.stageAlpha = 1;	//the stageAlpha setting used for trails
		this.canvas;
	}
	setup(canvas){
		this.canvas = canvas;
		background(140);			//sets background colour to a dark gray - not fully black - initially so that the background does not 'fade in' on page load
		colorMode(HSB);		//sets colour mode to hue, saturation, brightness to make random colour generation more interesting
		for (var i = 0; i < this.asteroids.length; i++) {			//initially populates the asteroids array with as many asteroids as specified in the initial object instance
			this.asteroids[i] = new Asteroid(random(width), random(height));		
		}
		this.cursor = new Cursor();	//sets up the cursor
	
	//create sliders for trail length and gravity strength
	}
	draw(){
		this.stageAlpha = Number(document.getElementById("trailSlider").value);	//sets the stageAlpha value to be the value of the corresponding slider
		fill(0, 0, 0, this.stageAlpha);				//background gets filled in with black at the opacity set in stageAlpha every frame, creating the trail effect on asteroids and the cursor
		rect(0, 0, width, height);		//this is the rectangle forming the background of the canvas
		stroke('red');		//draws a thin red outline on the canvas to make it stand out slightly more

		this.cursor.checkEdges();	//checks where cursor is, and ensures it cannot go offscreen
		this.cursor.disp();	//draws cursor on screen
		for (let i = 0; i < this.asteroids.length; i++) {		//on every canvas draw, updates all the asteroids
			this.asteroids[i].update();	//updates their properties
			this.asteroids[i].checkEdges();	//ensures they stay within the canvas
			this.asteroids[i].disp();	//draws them on screen
			this.collisionCheck(i);	//checks if they have impact with the cursor
		}
	}
	collisionCheck(i){			//function that calculates whether the cursor has collided with an asteroid
		var cursorLocation = createVector(mouseX, mouseY);		//uses p5 vectors the get location of the cursor
		var distanceBetween = p5.Vector.sub(cursorLocation, this.asteroids[i].location);		//calculates the distance between an asteroid and the cursor as a vector
		var distanceMag = p5.Vector.mag(distanceBetween);			//gets the size of the vector
		if (distanceMag < this.cursor.radius) {				//if the distance is below a certain threshold (the cursor radius), it counts as a collision
			this.cursor.hue = this.asteroids[i].hue;		//sets the colour of the cursor to the colour of the asteroid it collided with
			this.cursor.saturation = this.asteroids[i].saturation;
			this.cursor.brightness = this.asteroids[i].brightness;
			this.cursor.radius++;										//increase the radius of the cursor each time it eats an asteroid by 1
			var removed = this.asteroids.splice(i, 1);	//removes the asteroid from the array
		}
	}
}




class Cursor {		//cursor class - always at the mouse locatoin
	constructor() {
		this.location = new p5.Vector(mouseX, mouseY);		//sets location of the cursor to be wherever the mouse currently is
		this.radius = 8;		//sets cursor dot radius
		this.hue = 0;
		this.saturation = 100;
		this.brightness = 70;		//cursor colour initially defined, however can be changed by collisions with an asteroid - see line 14
	}
	checkEdges(){			//keeps the cursor to the edges of the creen regardless of actual cursor position - prevents it from escaping the window
		var mX = mouseX, mY = mouseY;
		if (mX > width) {
			mX = width;				//basically caps mouse coords at edges of the screen
		} else if (mX < 0) {
			mX = 0;
		}
		if (mY > height) {
			mY = height;
		} else if (mY < 0) {
			mY = 0;
		}
		this.location = new p5.Vector(mX, mY);		//updates the location of the mouse cursor - hence, this method is called every frame in the main draw() function in asteroidField2.js
	}
	disp() {		//draws the cursor as a circle on screen
		stroke(116, 100, 49);		//cursor border, to make it stand out from asteroids
		fill(this.hue, this.saturation, this.brightness, 1);		//cursor fill based on its current colour
		ellipse(mouseX, mouseY, this.radius);	//draws a circle at cursor location
	}
	isOnScreen(){		//boolean to check whether the mouse is currently located on the canvas
		var output = true;
		if (mouseX > asteroidField.canvas.width || mouseX < 0 || mouseY > asteroidField.canvas.height || mouseY < 0){
				output = false;
		} else {
			output = true;
			}
		 return output;
	}
}

class Asteroid {			//asteroid class
	constructor(x, y){			//constructor for asteroids - given x and y coordinate of asteroid
	this.acceleration;			//the acceleration of the asteroid in question
	this.location = createVector(x, y);			//location is given as a p5 vector
	this.velocity = createVector(0, 0);			//same for current velocity
	this.radius = 8;		//size of the asteroid
	this.topSpeed = 380;			//top speed is used to limit the speed of the asteroids so they cannot accelerate indefinitely
	this.hue = random(0, 255);				//each asteroid is set a random colour
	this.saturation = random(0, 255);
	this.brightness = random(50, 255);	//brightness given a lower bound to prevent asteroids from being too dark
	}
	update(){											//function to continuously update asteroid behavior - all asteroids constantly accelerate towards the cursor, with the magnitude of their acceleration dependent on their closeness to the cursor
		var mouse = createVector(mouseX, mouseY);			//first finds the position of the current mouse position
		var direction = p5.Vector.sub(mouse, this.location);		//the intended direction for any asteroid to accelerate in is towards the mouse, so the direction is a vector from the asteroid to the mouse position
		var magnitude = p5.Vector.mag(direction);		//the closer the asteroid is to the mouse, the faster it accelerates
		var gravityValue = Number(document.getElementById("gravitySlider").value);
		magnitude = magnitude * gravityValue;		//uses the gravity slider to change the magnitude of the acceleration, so the gravity of the cursor changes with the slider
		direction.mult(1 / magnitude);		//this uses the magnitude to increase the acceleration depending on distance
		direction.normalize();		//makes the direction vector into a unit vector
		direction.mult(gravityValue);		//once again uses the gravity slider
		this.acceleration = direction;		//sets the current acceleration to be in the direction of the cursor
		this.acceleration.mult(0.5);		//moderates the acceleration a bit
		if (mouseX > asteroidField.canvas.width || mouseX < 0 || mouseY > asteroidField.canvas.height || mouseY < 0) {
		}else{
			this.velocity.add(this.acceleration);			//imparts acceleration towards the cursor, but only if it is on screen - otherwise, the asteroids retain their current velocity
		}
		this.velocity.limit(this.topSpeed);			//ensures speed does not exceed top speed
		this.location.add(this.velocity);		//updates the location of the asteroids by adding the velocity as a vector to its current position
	}
	disp(){			//draws the asteroid on the screen
		noStroke();	//removes outline when drawing
		fill(this.hue, this.saturation, this.brightness, 1);	//fills in with the asteroid color
		ellipse(this.location.x, this.location.y, this.radius);		//draws the asteroid as a circle  at the asteroid's location
	}
	checkEdges(){				//makes asteroids bounce off the edges
		if (this.location.x > width) {
			this.location.x = width;	//ensures asteroids dont escape the bounds of the canvas
			this.velocity.x = this.velocity.x * -0.8;	//for frictionless collisions, set to -1 - otherwise, a decimal
		} else if (this.location.x < 0) {
			this.location.x = 0;		
			this.velocity.x = this.velocity.x * -0.8;
		}
		if (this.location.y > height) {
			this.location.y = height;	
			this.velocity.y = this.velocity.y * -0.8;
		} else if (this.location.y < 0) {
			this.location.y = 0;		
			this.velocity.y = this.velocity.y * -0.8;
		}
	}
}
